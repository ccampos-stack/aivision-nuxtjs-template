import{_ as e}from"./1u_dtusM.js";const r={};function c(n,t){return" Services page "}const s=e(r,[["render",c]]);export{s as default};
