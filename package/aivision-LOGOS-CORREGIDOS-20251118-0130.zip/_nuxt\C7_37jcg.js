import{p as a}from"./1u_dtusM.js";const s=a("/images/background/privacy-policy.png");export{s as M};
