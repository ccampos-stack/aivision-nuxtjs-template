import{_ as t,g as _,o as c}from"./1u_dtusM.js";const e={},o={class:"pt-lg-160 pt-md-100 pt-50"};function n(s,r){return c(),_("div",o)}const p=t(e,[["render",n]]);export{p as _};
