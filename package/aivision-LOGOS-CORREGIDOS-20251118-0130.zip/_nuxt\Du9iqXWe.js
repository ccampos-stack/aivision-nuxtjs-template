import{p as s}from"./1u_dtusM.js";const o=s("/images/svgs/google.svg"),t=s("/images/svgs/github.svg");export{t as a,o as g};
