import{p as a}from"./RAUpIr0_.js";const s=a("/images/background/privacy-policy.png");export{s as M};
