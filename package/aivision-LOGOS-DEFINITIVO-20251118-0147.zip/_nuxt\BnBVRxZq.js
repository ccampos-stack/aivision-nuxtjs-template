import{p as a}from"./Bv4oWz5C.js";const s=a("/images/background/privacy-policy.png");export{s as M};
