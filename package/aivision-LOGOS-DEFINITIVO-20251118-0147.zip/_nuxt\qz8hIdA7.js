import{p as s}from"./Bv4oWz5C.js";const o=s("/images/svgs/google.svg"),t=s("/images/svgs/github.svg");export{t as a,o as g};
