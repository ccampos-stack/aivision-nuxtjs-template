import{p as s}from"./RAUpIr0_.js";const o=s("/images/svgs/google.svg"),t=s("/images/svgs/github.svg");export{t as a,o as g};
